const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const DB_FILE = './chat.json';

// إنشاء الملف لو مش موجود
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify([]));
}

// دالة لحفظ الرسائل
function saveMessage(username, message) {
  const messages = JSON.parse(fs.readFileSync(DB_FILE));
  messages.push({ username, message, timestamp: new Date().toISOString() });
  fs.writeFileSync(DB_FILE, JSON.stringify(messages, null, 2));
}

// واجهة الموقع
app.use(express.static('public'));

io.on('connection', socket => {
  console.log('✅ مستخدم جديد متصل');

  // إرسال كل الرسائل القديمة عند الاتصال
  const oldMessages = JSON.parse(fs.readFileSync(DB_FILE));
  socket.emit('chatHistory', oldMessages);

  socket.on('sendMessage', data => {
    saveMessage(data.username, data.message);
    io.emit('newMessage', data);
  });

  socket.on('disconnect', () => {
    console.log('❌ المستخدم خرج');
  });
});
//  z .خليها:
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ WeboChat شغال على http://0.0.0.0:${PORT}`);
});
